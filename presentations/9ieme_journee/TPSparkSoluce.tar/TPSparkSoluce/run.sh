#!/bin/bash

# Check if we have at least one paremeter
if [ $# -ne 2 ]; 
    then echo "format : $0 className HDFSdirectory [args]"
    exit 1
fi

# Compile automatically if the jar file is missing
# Or a source file has been modified since last compiling
if [ ! -f target/TPSpark-1.0.jar ]; then
    echo ===========
    echo TPSpark-1.0.jar does not exist. Compiling...
    echo ===========
	mvn package
        if [ $? -ne 0 ]; then exit; fi
fi
jarmodified=`stat -c "%Y" target/TPSpark-1.0.jar`
scriptmodified=`find src/ -printf "%T@+\n" | sort -rn | head -n 1`
if [[ $jarmodified < $scriptmodified ]]; then
    echo ===========
    echo Source file changed. Recompiling...
    echo ===========
	mvn package
        if [ $? -ne 0 ]; then exit; fi
fi
class=$1
dir=$2
shift 2
echo ===========
echo execution
echo ===========
sleep 1
# Run spark-submit
spark-submit --conf spark.executor.instances=2 --executor-cores 1 --executor-memory 1G --class $class target/TPSpark-1.0.jar $dir $*
#spark-submit --conf spark.dynamicAllocation.maxExecutors=2 --executor-cores 1 --executor-memory 2G --class fr.upsud.hadoop.$class target/TPSpark-1.0.jar $dir $*

