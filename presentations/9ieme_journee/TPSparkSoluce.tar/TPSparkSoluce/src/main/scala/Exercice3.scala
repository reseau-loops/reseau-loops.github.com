import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Exercice 3 : Completez le code a trous ci-dessous de maniere a calculer la temperature maximale par couple (annee, ID de station).
// Inspirez-vous du code fourni en Exercice 1 et des indices fournis dans le code

object Exercice3 {
  def main(args: Array[String]) {
    // Suppression d'une partie des messages d'information tres verbeux
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    // En dehors de spark-shell, il faut declarer manuellement le contexte
    val conf = new SparkConf().setAppName("demo")
    val sc = new SparkContext(conf)

    // Verification du chemin en entree
    if(args.length != 1) {
      println("Usage: Exercice3 <input_path>")
      System.exit(1)
    }

    // Chargement des fichiers du NCDC
    val lines = sc.textFile(args(0))
    // Interpretation de chaque ligne pour creer une entree NCDCData
    val records = lines.map(s => new NCDCData(s))
    // Filtrage des donnees invalides
    val filtered = records.filter(data => (data.airTemperature != 9999 && data.airTemperatureQuality.matches("[01459]")))

    // Creation des couples ((annee, ID), temperature)
    // Les "tuples" scala s'ecrivent tel quel : (v1, v2)
    val tuples = filtered.map(data => ((data.year, data.USAFID), data.airTemperature))

    // Calcul de la temperature maximale par cle
    val maxTemps = tuples.reduceByKey((t1, t2) => math.max(t1, t2))

    // Affichage des resultats
    maxTemps.sortByKey(true).collect().foreach(println)
  }
}
