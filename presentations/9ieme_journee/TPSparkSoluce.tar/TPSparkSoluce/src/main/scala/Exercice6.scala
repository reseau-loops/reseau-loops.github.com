import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Exercice 6 : Completez le code a trous ci-dessous de maniere a calculer la temperature moyenne par annee

object Exercice6 {
  def main(args: Array[String]) {
    // Suppression d'une partie des messages d'information tres verbeux
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    // En dehors de spark-shell, il faut declarer manuellement le contexte
    val conf = new SparkConf().setAppName("demo")
    val sc = new SparkContext(conf)

    // Verification du chemin en entree
    if(args.length != 1) {
      println("Usage: Exercice6 <input_path>")
      System.exit(1)
    }

    // Chargement des fichiers du NCDC
    val lines = sc.textFile(args(0))
    // Interpretation de chaque ligne pour creer une entree NCDCData
    val records = lines.map(s => new NCDCData(s))
    // Filtrage des donnees invalides
    val filtered = records.filter(data => (data.airTemperature != 9999 && data.airTemperatureQuality.matches("[01459]")))

    // On va construire des couples de valeurs (totalTemp, nombreMesures) et on determinera au dernier moment la temperature moyenne
    // Fonctionne bien tant que totalTemp ne depasse pas Integer.MaxInt
    // var totalTemps = filtered.map(data => (data.year, (data.airTemperature, 1))).reduceByKey{case ((t1, c1), (t2, c2)) => (t1+t2, c1+c2)}.map{case (year, (t,c)) => (year, t/c)}

    // La meme chose en utilisant aggregateByKey, supposement plus rapide
    // Notez que "somme" corresond ici au couple (sommeTemperatures, compteTemperatures)
    var totalTemps = filtered.map(data => (data.year, data.airTemperature)).aggregateByKey((0, 0))(
        (sum, value) => (sum._1 + value, sum._2 + 1),
        (sum1, sum2) => (sum1._1 + sum2._1, sum1._2 + sum2._2)
    ).map{case (year, (t,c)) => (year, t/c)}

    // Affichage des resultats
    totalTemps.sortByKey(true).collect().foreach(println)
  }
}
