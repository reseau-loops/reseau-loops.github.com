import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Exercice 1 :
// 1. Executez ce programme a l'aide de la commande "./run.sh Exercice1 /ncdc/lite"
// 2. Verifiez le resultat sous forme de couples (USAFID, temperature). Note : les temperatures sont en dixiemes de degres
// 3. Analysez le code present dans la methode main()
// 4. Analysez le code present dans src/main/java/NCDCData.java
// 5. Decommentez le code supprimant les messages d'information et reexecutez le programme

object Exercice1 {
  def main(args: Array[String]) {
    // Suppression d'une partie des messages d'information tres verbeux
    // Decommentez ce code des que possible
    /*
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)
    */

    // En dehors de spark-shell, il faut declarer manuellement le contexte
    val conf = new SparkConf().setAppName("demo")
    val sc = new SparkContext(conf)

    // Verification du chemin en entree
    if(args.length != 1) {
      println("Usage: Exercice1 <input_path>")
      System.exit(1)
    }

    // Chargement des fichiers du NCDC
    val lines = sc.textFile(args(0))
    // Interpretation de chaque ligne pour creer une entree NCDCData
    val records = lines.map(s => new NCDCData(s))
    // Filtrage des donnees invalides
    val filtered = records.filter(data => (data.airTemperature != 9999 && data.airTemperatureQuality.matches("[01459]")))
    // Creation des couples (ID, temperature)
    val tuples = filtered.map(data => (data.USAFID, data.airTemperature))
    // Calcul de la temperature maximale par cle
    val maxTemps = tuples.reduceByKey((t1, t2) => math.max(t1, t2))

    // Affichage des resultats. Selon la taille du jeu de donnees, on utilisera collect (toutes les valeurs)
    // ou take(X) (limitation a X valeurs)
    //maxTemps.take(100).foreach(println)
    maxTemps.sortByKey(true).collect().foreach(println)
  }
}
