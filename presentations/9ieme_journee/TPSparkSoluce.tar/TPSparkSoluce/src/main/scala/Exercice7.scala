import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Exercice 7 :
// 1. Analysez le code ci-dessous qui met en place SparkSQL pour effectuer des requetes SQL sur vos donnees
// 2. Refaites les exercices precedents a la suite de la requete de demonstration en utilisant des requetes SQL

// on definit une nouvelle classe plus appropriee a son interpretation par spark SQL
case class NCDCData2(
    USAFID: String,
    year: Integer, 
    month: Integer,
    day: Integer, hour: Integer,
    minute: Integer,
    stationName: String,
    airTemperature: Integer,
    airTemperatureQuality: String
)

case class ISDData(USAFID: String, stationName: String)


object Exercice7 {
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    val conf = new SparkConf().setAppName("Exercice7")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    import sqlContext.implicits._

    // Recuperation des records
    val records = sc.textFile("/ncdc/lite/*").map(s => NCDCData2(
      s.substring(4, 10),
      Integer.parseInt(s.substring(15, 19)),
      Integer.parseInt(s.substring(19, 21)),
      Integer.parseInt(s.substring(21, 23)),
      Integer.parseInt(s.substring(23, 25)),
      Integer.parseInt(s.substring(25, 27)),
      s.substring(51, 56),
      Integer.parseInt(s.substring(87, 92)),
      s.substring(92, 93)
    ))
    // Conversion en DataFrame
    val recordsDF = records.toDF()
    // Enregistrement du DataFrame sous forme de table SparkSQL
    recordsDF.registerTempTable("records")

    val query = sqlContext.sql("""SELECT USAFID, max(airTemperature) FROM records
        WHERE airTemperature != 9999 AND airTemperatureQuality rlike "[01459]"
        GROUP BY USAFID ORDER BY USAFID""")
    query.collect().foreach(println)


    /*
    val queryExercice2 = sqlContext.sql("""SELECT year, max(airTemperature) FROM records
        WHERE airTemperature != 9999 AND airTemperatureQuality rlike "[01459]"
        GROUP BY year ORDER BY year""")
    queryExercice2.collect().foreach(println)
    */

    /*
    val queryExercice3 = sqlContext.sql("""SELECT year, USAFID, max(airTemperature) FROM records
        WHERE airTemperature != 9999 AND airTemperatureQuality rlike "[01459]"
        GROUP BY year, USAFID ORDER BY year, USAFID""")
    queryExercice3.collect().foreach(println)
    */

    /*
    val queryExercice4 = sqlContext.sql("""SELECT year, min(airTemperature), max(airTemperature) FROM records
        WHERE airTemperature != 9999 AND airTemperatureQuality rlike "[01459]"
        GROUP BY year ORDER BY year""")
    queryExercice4.collect().foreach(println)
    */

    /*
    // Chargement des donnees ISD
    val isdData = sc.textFile("/ncdc/isd-history.csv")
    val isdFiltered = isdData.map(s => s.split(",")).map(s => new ISDData(s(0).drop(1).dropRight(1), s(2).drop(1).dropRight(1)))
    val isdDF = isdFiltered.toDF()
    isdDF.registerTempTable("isd")
    val queryExercice5 = sqlContext.sql("""SELECT isd.stationName, max(airTemperature) FROM records JOIN isd ON records.USAFID = isd.USAFID
        WHERE airTemperature != 9999 AND airTemperatureQuality rlike "[01459]"
        GROUP BY isd.stationName ORDER BY isd.stationName""")
    queryExercice5.collect().foreach(println)
    */

    /*
    val queryExercice6 = sqlContext.sql("""SELECT year, avg(airTemperature) FROM records
        WHERE airTemperature != 9999 AND airTemperatureQuality rlike "[01459]"
        GROUP BY year ORDER BY year""")
    queryExercice6.collect().foreach(println)
    */
  }
}

