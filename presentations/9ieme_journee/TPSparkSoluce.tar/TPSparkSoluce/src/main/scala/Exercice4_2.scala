import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Exercice 4.2 : Completez le code a trous ci-dessous de maniere a calculer les temperatures maximale et minimale en une passe par annee.
// Dans cet exercice vous utiliserez la methode aggregateByKey

object Exercice4_2 {
  def main(args: Array[String]) {
    // Suppression d'une partie des messages d'information tres verbeux
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    // En dehors de spark-shell, il faut declarer manuellement le contexte
    val conf = new SparkConf().setAppName("demo")
    val sc = new SparkContext(conf)

    // Verification du chemin en entree
    if(args.length != 1) {
      println("Usage: Exercice4_2 <input_path>")
      System.exit(1)
    }

    // Chargement des fichiers du NCDC
    val lines = sc.textFile(args(0))
    // Interpretation de chaque ligne pour creer une entree NCDCData
    val records = lines.map(s => new NCDCData(s))
    // Filtrage des donnees invalides
    val filtered = records.filter(data => (data.airTemperature != 9999 && data.airTemperatureQuality.matches("[01459]")))
    // Creation des couples (annee, temperature)
    val tuples = filtered.map(data => (data.year, data.airTemperature))

    // Calcul des temperatures minimale et maximale par cle
    // La methode aggregateByKey s'ecrit de la facon suivante :
    // aggregateByKey(U zerovalue)(seqOp : (U,V) => U, combOp : (U, U) => U)
    // Aide : U est la valeur de depart (Int.MaxValue, Int.MinValue), seqOp compare un tuple (min, max) avec un entier, combOp compare deux tuples (min, max)
    val minmaxtemps = tuples.aggregateByKey((Int.MaxValue, Int.MinValue))(
        (U1, v) => (Math.min(U1._1, v), Math.max(U1._2, v)),
        (U1, U2) => (Math.min(U1._1, U2._1), Math.max(U1._2, U2._2))
    )

    // Affichage des resultats
    minmaxtemps.sortByKey(true).collect().foreach(println)
  }
}
