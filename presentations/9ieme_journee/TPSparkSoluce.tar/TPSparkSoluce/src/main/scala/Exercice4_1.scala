import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Exercice 4.1 : Completez le code a trous ci-dessous de maniere a calculer les temperatures maximale et minimale en une passe par annee.
// Dans cet exercice vous creerez des tuples (temp, temp) et calculerez la valeur minimale de l'element de gauche et maximale de l'element de droite.

object Exercice4_1 {
  def main(args: Array[String]) {
    // Suppression d'une partie des messages d'information tres verbeux
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    // En dehors de spark-shell, il faut declarer manuellement le contexte
    val conf = new SparkConf().setAppName("demo")
    val sc = new SparkContext(conf)

    // Verification du chemin en entree
    if(args.length != 1) {
      println("Usage: Exercice4_1 <input_path>")
      System.exit(1)
    }

    // Chargement des fichiers du NCDC
    val lines = sc.textFile(args(0))
    // Interpretation de chaque ligne pour creer une entree NCDCData
    val records = lines.map(s => new NCDCData(s))
    // Filtrage des donnees invalides
    val filtered = records.filter(data => (data.airTemperature != 9999 && data.airTemperatureQuality.matches("[01459]")))
    // Creation des couples (annee, (temperature, temperature))
    val tuples = filtered.map(d => (d.year, (d.airTemperature, d.airTemperature)))

    // Calcul des temperatures minimale et maximale par cle
    // Notez que les valeurs d'un tuple peuvent etre accedees de deux facons. Par exemple :
    // 1. reduceByKey((t1, t2) => math.max(t1._1, t2._1))
    // 2. reduceByKey{case ((x1, x2), (y1, y2)) => math.max(x1, y1)}
    // Ces exemples ne constituent qu'une partie de la solution et ne sont pas directement fonctionels
    // Solution 1 :
    val minmaxtemps = tuples.reduceByKey((t1, t2) => (math.min(t1._1, t2._1), math.max(t1._2, t2._2)))
    // Solution 2 :
    // val minmaxtemps = tuples.reduceByKey{ case ((t1min, t1max), (t2min, t2max)) => (math.min(t1min, t2min), math.max(t1max, t2max))}

    // Affichage des resultats
    minmaxtemps.sortByKey(true).collect().foreach(println)
  }
}
