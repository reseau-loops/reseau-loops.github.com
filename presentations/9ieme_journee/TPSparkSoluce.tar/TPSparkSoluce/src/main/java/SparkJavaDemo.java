import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import scala.Tuple2;
import java.util.Map;

public class SparkJavaDemo {
  
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Usage: SparkJavaDemo <input path>");
            System.exit(-1);
        }

        SparkConf conf = new SparkConf().setAppName("SparkJavaDemo");
        JavaSparkContext sc = new JavaSparkContext(conf);

        // Chargement des fichiers du NCDC
        JavaRDD<String> lines = sc.textFile(args[0]);
        // Interpretation de chaque ligne pour creer une entree NCDCData
        JavaRDD<NCDCData> records = lines.map(new Function<String, NCDCData>() {
            @Override public NCDCData call(String s) {
                return new NCDCData(s);
          }});
        // Filtrage des donnees invalides
        JavaRDD<NCDCData> filtered = records.filter(new Function<NCDCData, Boolean>() {
            @Override public Boolean call(NCDCData data) {
                return data.airTemperature != 9999 && data.airTemperatureQuality.matches("[01459]");
            }
        });
        // Creation des couples (ID, temperature)
        JavaPairRDD<String, Integer> tuples = filtered.mapToPair(
            new PairFunction<NCDCData, String, Integer>() {
                @Override public Tuple2<String, Integer> call(NCDCData data) {
                    return new Tuple2<String, Integer>(
                        data.USAFID, data.airTemperature);
                }
            }
        );
        // Calcul de la temperature maximale par cle
        JavaPairRDD<String, Integer> maxTemps = tuples.reduceByKey(
            new Function2<Integer, Integer, Integer>() {
                @Override public Integer call(Integer i1, Integer i2) {
                    return Math.max(i1, i2);
                }
            }
        );
        // Affichage des resultats. Selon la taille du jeu de donnees, on utilisera collectAsMap (toutes les valeurs)
        // ou take(X) (limitation a X valeurs)
        Map<String, Integer> results = maxTemps.collectAsMap();
        for(String key: results.keySet()) {
            System.out.format("(%s,%d)%n", key, results.get(key));
        }
    }
}
