import java.io.Serializable;

public class NCDCData implements Serializable {
    public String USAFID;
    // Note : le NCDCID n'est pas toujours defini (en particulier debut 1900)
    public String NCDCID;
    public int year;
    public int month;
    public int day;
    public int hour;
    public int minute;
    public String stationName;
    // Note : la temperature est exprimee en dixiemes de degres
    public int airTemperature;
    public String airTemperatureQuality;

    public NCDCData(String s) {
        this.USAFID = s.substring(4, 10);
        this.NCDCID = s.substring(10, 15);
        this.year = Integer.parseInt(s.substring(15, 19));
        this.month = Integer.parseInt(s.substring(19, 21));
        this.day = Integer.parseInt(s.substring(21, 23));
        this.hour = Integer.parseInt(s.substring(23, 25));
        this.minute = Integer.parseInt(s.substring(25, 27));
        this.stationName = s.substring(51, 56);
        this.airTemperature = Integer.parseInt(s.substring(87, 92));
        this.airTemperatureQuality = s.substring(92, 93);
    }
}
