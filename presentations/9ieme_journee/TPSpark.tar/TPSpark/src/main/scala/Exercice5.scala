import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Exercice 5 : Completez le code a trous ci-dessous de maniere a calculer la temperature maximale par nom de station.

object Exercice5 {
  def main(args: Array[String]) {
    // Suppression d'une partie des messages d'information tres verbeux
    Logger.getLogger("org").setLevel(Level.OFF)
    Logger.getLogger("akka").setLevel(Level.OFF)

    // En dehors de spark-shell, il faut declarer manuellement le contexte
    val conf = new SparkConf().setAppName("demo")
    val sc = new SparkContext(conf)

    // Verification du chemin en entree
    if(args.length != 1) {
      println("Usage: Exercice5 <input_path>")
      System.exit(1)
    }

    // Chargement des fichiers du NCDC
    val lines = sc.textFile(args(0))
    // Interpretation de chaque ligne pour creer une entree NCDCData
    val records = lines.map(s => new NCDCData(s))
    // Filtrage des donnees invalides
    val filtered = records.filter(data => (data.airTemperature != 9999 && data.airTemperatureQuality.matches("[01459]")))

    // Creation des couples (USAFID, temperature)
    // TODO

    // Calcul de la temperature maximale par cle
    // TODO


    // Chargement des donnees depuis le repertoire HDFS /ncdc/isd-history.csv
    // TODO

    // Les donnees sont de la forme "949999","00338","PORTLAND (CASHMORE)","AS","","","-38.320","+141.480","+0081.0","19690724","19781113"
    // Les champs d'interet sont le premier (USAFID) et le 3e (nom de station)
    // Recuperation des couples (USAFID, nom de station)
    // Note : le decoupage se fait via split(',') ; on peut suprimer les guillemets avec une commande du type val.drop(1).dropRight(1)
    // TODO

    // Jointure entre les donnees de temperature et de noms de station
    // La cle commune est l'USAFID
    // Spark permet de joindre des RDD de facon tres simple a l'aide de la methode join qui cree a partir de tuples de type (K, U) et (K, V), des tuples de type (K, (U, V)).
    // TODO

    // Recuperation des tuples (nom de station, temperature maximale) a partir du resultat ci-dessus via une operation map()
    // TODO

    // Affichage des resultats
    // TODO
  }
}
